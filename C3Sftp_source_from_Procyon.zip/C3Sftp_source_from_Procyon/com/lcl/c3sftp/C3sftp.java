// 
// Decompiled by Procyon v0.5.36
// 

package com.lcl.c3sftp;

import com.lcl.c3sftp.business.C3SFTPLogicBean;

public class C3sftp
{
    public static void main(final String[] args) {
        try {
            final C3SFTPLogicBean logicBean = new C3SFTPLogicBean();
            logicBean.sftpC3();
        }
        catch (Exception ex) {
            ex.printStackTrace();
            System.out.println(ex.getMessage());
            System.exit(100);
        }
    }
}
