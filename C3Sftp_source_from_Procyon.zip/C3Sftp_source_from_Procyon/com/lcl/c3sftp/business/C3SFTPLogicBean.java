// 
// Decompiled by Procyon v0.5.36
// 

package com.lcl.c3sftp.business;

import java.io.PrintWriter;
import java.io.Writer;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.Reader;
import java.io.BufferedReader;
import java.io.FileReader;
import java.util.Arrays;
import java.util.Vector;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSch;
import com.lcl.c3sftp.C3sftp;
import java.util.Iterator;
import java.io.IOException;
import java.io.File;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.core.LoggerContext;
import org.apache.log4j.PropertyConfigurator;
import java.io.InputStream;
import java.io.FileInputStream;
import java.util.Properties;
import org.apache.log4j.Logger;
import java.util.HashMap;

public class C3SFTPLogicBean
{
    private static final String GLOBALVARIABLESPROPERTIES = "globals.properties";
    private static final String LOG4JPROPERTIES = "Odslog4j.xml";
    private static final String PROPERTIESPATH = "C:\\x\\prod\\ods\\scripts\\prop\\";
    private HashMap globalVariables;
    private Logger log;
    private Properties globalProperties;
    
    public void initLogger(final String className) {
        this.log = Logger.getLogger(className);
    }
    
    private void initProperties() {
        try {
            final Properties globalVarProp = new Properties();
            String propsName = "C:\\x\\prod\\ods\\scripts\\prop\\globals.properties";
            final FileInputStream fstream = new FileInputStream(propsName);
            globalVarProp.load(fstream);
            for (final String key : globalVarProp.keySet()) {
                this.globalVariables.put(key, globalVarProp.getProperty(key));
            }
            fstream.close();
            this.setGlobalProperties(globalVarProp);
            propsName = "C:\\x\\prod\\ods\\scripts\\prop\\Odslog4j.xml";
            PropertyConfigurator.configure(propsName);
            final LoggerContext context = (LoggerContext)LogManager.getContext(false);
            final File file = new File(propsName);
            context.setConfigLocation(file.toURI());
            this.log.debug((Object)"Initiated Log4j");
        }
        catch (IOException ioe) {
            ioe.printStackTrace();
            this.log.fatal((Object)("Error Load properties: " + ioe.getMessage()));
        }
        catch (Exception e) {
            e.printStackTrace();
            this.log.fatal((Object)e.getMessage());
        }
    }
    
    public String getGlobalVariable(final String globalVariableName) {
        return (this.globalVariables.get(globalVariableName) != null) ? this.globalVariables.get(globalVariableName) : null;
    }
    
    public boolean isTest() {
        return this.getGlobalVariable("IS_TEST").equals("Y");
    }
    
    public Properties getGlobalProperties() {
        return this.globalProperties;
    }
    
    public void setGlobalProperties(final Properties globalProperties) {
        this.globalProperties = globalProperties;
    }
    
    public C3SFTPLogicBean() {
        this.globalVariables = new HashMap();
        this.log = Logger.getLogger(C3sftp.class.getName());
        this.globalProperties = null;
        this.initProperties();
    }
    
    public void sftpC3() throws Exception {
        try {
            final String user = this.getGlobalVariable("C3_SFTP_User");
            final String password = this.getGlobalVariable("C3_SFTP_Password");
            final String host = this.getGlobalVariable("C3_SFTP_Host");
            final String remotePath = this.getGlobalVariable("C3_SFTP_RemotePath");
            final String localPath = this.getGlobalVariable("C3_SFTP_LocalPath");
            final int port = 22;
            File[] listFiles;
            for (int length = (listFiles = new File(localPath).listFiles()).length, i = 0; i < length; ++i) {
                final File file = listFiles[i];
                if (!file.isDirectory()) {
                    file.delete();
                }
            }
            try {
                final JSch jsch = new JSch();
                final Session session = jsch.getSession(user, host, port);
                session.setPassword(password);
                session.setConfig("StrictHostKeyChecking", "no");
                this.log.debug((Object)"Establishing Connection...");
                session.connect();
                this.log.debug((Object)"Connection established.");
                this.log.debug((Object)"Creating SFTP Channel.");
                final ChannelSftp sftpChannel = (ChannelSftp)session.openChannel("sftp");
                sftpChannel.connect();
                this.log.debug((Object)"SFTP Channel created.");
                sftpChannel.cd(remotePath);
                System.out.println("Current Folder: " + sftpChannel.pwd());
                this.log.debug((Object)sftpChannel.pwd());
                final Vector<ChannelSftp.LsEntry> v = (Vector<ChannelSftp.LsEntry>)sftpChannel.ls(".");
                this.log.debug((Object)v.size());
                for (final ChannelSftp.LsEntry file2 : v) {
                    final String filename = file2.getFilename();
                    this.log.debug((Object)String.format("File - %s", filename));
                    if (!file2.getAttrs().isDir()) {
                        sftpChannel.get(filename, localPath);
                    }
                }
                sftpChannel.disconnect();
                session.disconnect();
                this.mergeFiles(localPath);
            }
            catch (Exception e) {
                this.log.debug((Object)e.getMessage());
                throw e;
            }
        }
        catch (Exception ex) {
            this.log.debug((Object)ex.getMessage());
            throw ex;
        }
    }
    
    public void mergeFiles(final String localPath) throws Exception {
        try {
            String[] dirListing = null;
            this.log.debug((Object)localPath);
            final File dir = new File(localPath);
            dirListing = dir.list();
            this.log.debug((Object)dirListing.length);
            Arrays.sort(dirListing);
            for (int i = 0; i < dirListing.length; ++i) {
                final File dataFile = new File(String.valueOf(localPath) + "/" + dirListing[i]);
                this.log.debug((Object)(String.valueOf(localPath) + "/" + dirListing[i]));
                if (dataFile.isFile()) {
                    final String filename = dataFile.getName();
                    final String fileDate = filename.substring(0, 10);
                    final String tableName = filename.substring(17, filename.lastIndexOf(".dat"));
                    this.log.debug((Object)("File Name: " + filename));
                    this.log.debug((Object)("File Date: " + fileDate));
                    this.log.debug((Object)("Table Name: " + tableName));
                    final BufferedReader in = new BufferedReader(new FileReader(String.valueOf(localPath) + "/" + dirListing[i]));
                    final BufferedWriter out = new BufferedWriter(new FileWriter(String.valueOf(localPath) + "/" + fileDate + "_" + tableName + ".dat", true));
                    final PrintWriter outwriter = new PrintWriter(out);
                    this.log.debug((Object)(String.valueOf(localPath) + "/" + fileDate + "_" + tableName + ".dat"));
                    in.readLine();
                    String mystring;
                    while ((mystring = in.readLine()) != null) {
                        outwriter.println(mystring);
                    }
                    out.flush();
                    out.close();
                    in.close();
                }
            }
        }
        catch (Exception ex) {
            this.log.debug((Object)ex.getMessage());
            throw ex;
        }
    }
}
